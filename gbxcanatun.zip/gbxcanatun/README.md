# Landing Gracie Barra Xcanatún

Archivos: `index.html`, `css/styles.css`, `js/main.js`, `apps-script/Code.gs`.
Abre `index.html` en el navegador (o súbelo a tu hosting) y funciona sin instalar nada.

## 1) Conectar el formulario a Google Sheets
1. Crea una hoja de cálculo en Google Sheets.
2. Extensiones > Apps Script. Borra el contenido y pega `apps-script/Code.gs`.
3. Implementar > Nueva implementación > tipo "Aplicación web".
   - Ejecutar como: **Yo**
   - Quién tiene acceso: **Cualquier persona**
4. Copia la URL que termina en `/exec`.
5. En `js/main.js`, pega esa URL en `CONFIG.SHEETS_URL`.
Cada solicitud agrega una fila (fecha, nombre, WhatsApp, para quién, edad, programa, turno, origen, UTM, estatus).
Si cambias el código del script, haz una *nueva versión* de la implementación.

## 2) WhatsApp
Número en `CONFIG.WHATSAPP` (formato `52` + 10 dígitos). Todos los botones con `data-wa="mensaje"` abren el chat con ese mensaje.

## 3) Mapa
Google Maps interactivo (arrastrar, zoom). Si la ubicación no cae exacto, ajusta `CONFIG.MAP_QUERY`
o pega el iframe de "Compartir > Insertar un mapa" desde Google Maps en `#mapFrame`.

## 4) Pendientes antes de publicar
- Reemplazar los círculos con iniciales por fotos oficiales (clase `.avatar` en `js/main.js`).
- Pegar el aviso de privacidad oficial en el modal al final de `index.html`.
- Confirmar días de la semana de los horarios.
